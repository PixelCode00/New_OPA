<template>
    <div>Hello from the other side blade </div>
</template>